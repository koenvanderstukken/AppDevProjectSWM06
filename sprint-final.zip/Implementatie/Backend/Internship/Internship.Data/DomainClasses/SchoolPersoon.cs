﻿namespace Internship.Data.DomainClasses
{
    public class SchoolPersoon : Persoon
    {
        public string Nummer { get; set; }
        public string SchoolMail { get; set; }
    }
}