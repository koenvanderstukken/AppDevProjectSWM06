﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internship.Data.DomainClasses
{
    public class BedrijfsPersoon : Persoon
    {
        public String Title { get; set; }
    }
}
