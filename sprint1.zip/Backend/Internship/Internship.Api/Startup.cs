﻿using System;
using System.Collections.Generic;
using System.Linq;
using Internship.Api.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Owin;
using Microsoft.Owin.Cors;

[assembly: OwinStartup(typeof(Internship.Api.Startup))]

namespace Internship.Api
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            ConfigureAuth(app);
            createUserAndRoles();
        }

        private void createUserAndRoles()
        {
            ApplicationDbContext context = new ApplicationDbContext();

            var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));
            var userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));

            if (!roleManager.RoleExists("Teacher"))
            {
                var role = new IdentityRole();
                role.Name = "Teacher";
                roleManager.Create(role);

                var user = new ApplicationUser();
                user.Email = "lector@pxl.be";
                user.UserName = user.Email;
                var result = userManager.Create(user, "lector");

                if (result.Succeeded)
                    userManager.AddToRole(user.Id, "Teacher");
            }

            if (!roleManager.RoleExists("Student"))
            {
                var role = new IdentityRole();
                role.Name = "Student";
                roleManager.Create(role);

                var user = new ApplicationUser();
                user.Email = "student@student.pxl.be";
                user.UserName = user.Email;
                var result = userManager.Create(user, "student");

                if (result.Succeeded)
                    userManager.AddToRole(user.Id, "Student");
            }

            if (!roleManager.RoleExists("Company"))
            {
                var role = new IdentityRole();
                role.Name = "Company";
                roleManager.Create(role);

                var user = new ApplicationUser();
                user.Email = "bedrijf@gmail.com";
                user.UserName = user.Email;
                var result = userManager.Create(user, "bedrijf");

                if (result.Succeeded)
                    userManager.AddToRole(user.Id, "Company");
            }
        }
    }
}
