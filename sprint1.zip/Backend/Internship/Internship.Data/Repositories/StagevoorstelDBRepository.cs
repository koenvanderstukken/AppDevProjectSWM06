﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;

namespace Internship.Data.Repositories
{
    public class StagevoorstelDBRepository : IStagevoorstelRepository
    {
        private InternshipDB _context;

        public StagevoorstelDBRepository(InternshipDB context)
        {
            _context = context;
        }

        public IEnumerable<Stagevoorstel> GetAll()
        {
            return _context.Stagevoorstellen.ToList();
        }

        public Stagevoorstel Post(Stagevoorstel stagevoorstel)
        {
            _context.Stagevoorstellen.Add(stagevoorstel);
            _context.SaveChanges();
            return stagevoorstel;
        }

        public Stagevoorstel Get(int id)
        {
            return _context.Stagevoorstellen.FirstOrDefault(s => s.Id == id);
        }

        public void Update(Stagevoorstel stagevoorstel)
        {
            var contextStagevoorstel = _context.Stagevoorstellen.FirstOrDefault(s => s.Id == stagevoorstel.Id);
            /*
            _context.Stagevoorstellen.Attach(stagevoorstel);
            var entry = _context.Entry(stagevoorstel);
            entry.Property(e => e.TimeStamp).IsModified = true;
            entry.Property(e => e.Opdrachtgever).IsModified = true;
            entry.Property(e => e.Status).IsModified = true;
            entry.Property(e => e.AantalITWerknemers).IsModified = true;
            entry.Property(e => e.AantalITBegeleiders).IsModified = true;
            entry.Property(e => e.AantalWerknemers).IsModified = true;
            entry.Property(e => e.Contactpersoon).IsModified = true;
            entry.Property(e => e.Bedrijfspromotor).IsModified = true;
            entry.Property(e => e.Stageopdracht).IsModified = true;
            entry.Property(e => e.AantalGewensteStagiairs).IsModified = true;
            entry.Property(e => e.VoorkeurAfstudeerrichting).IsModified = true;
            entry.Property(e => e.InleidendeActiviteiten).IsModified = true;
            entry.Property(e => e.VoorkeurStudenten).IsModified = true;
            entry.Property(e => e.Bemerkingen).IsModified = true;
            entry.Property(e => e.Review).IsModified = true;
            entry.Property(e => e.Verstuurd).IsModified = true;
            entry.Property(e => e.VerstuurdDoor).IsModified = true;
            */
            _context.Entry(contextStagevoorstel).CurrentValues.SetValues(stagevoorstel);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            Stagevoorstel stagevoorstel = _context.Stagevoorstellen.FirstOrDefault(s => s.Id == id);
            _context.Stagevoorstellen.Remove(stagevoorstel);
            _context.SaveChanges();
        }
    }
}
