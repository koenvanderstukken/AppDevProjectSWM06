﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;

namespace Internship.Data.Repositories
{
   public class StageopdrachtenDbRepository : IStageopdrachtenRepository
    {

        private InternshipDB _context;

        public StageopdrachtenDbRepository(InternshipDB context)
        {
            _context = context;
        }

        public Stageopdracht Get(int id)
        {
            return _context.Stageopdrachten.FirstOrDefault(s => s.Id == id);
        }

        public IEnumerable<Stageopdracht> GetAll()
        {
            return _context.Stageopdrachten.ToList();
        }

        public Stageopdracht Post(Stageopdracht stageOpdracht)
        {
            _context.Stageopdrachten.Add(stageOpdracht);
            _context.SaveChanges();
            return stageOpdracht;
        }

        public void Update(Stageopdracht stageOpdracht)
        {
            // TODO
        }

        public void Delete(int id)
        {
            Stageopdracht stageOpdracht = _context.Stageopdrachten.FirstOrDefault(o => o.Id == id);
            _context.Stageopdrachten.Remove(stageOpdracht);
            _context.SaveChanges();
        }

        public IEnumerable<Stageopdracht> GetAllGoedgekeurdeStageopdrachten()
        {
            return _context.Stageopdrachten.Where(s => s.Status == Status.Goedgekeurd).ToList();
        }
    }
}
