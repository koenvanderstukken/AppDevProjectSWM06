﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;
using System.Data.Entity;

namespace Internship.Data.Repositories
{
    public class BedrijfDBRepository : IBedrijfRepository
    {
        private InternshipDB _context;

        public BedrijfDBRepository(InternshipDB context)
        {
            _context = context;
        }

        public IEnumerable<Bedrijf> GetAll()
        {
            return _context.Bedrijven.ToList();
        }

        public Bedrijf Get(int id)
        {
            return _context.Bedrijven.FirstOrDefault(s => s.Id == id);
        }

        public Bedrijf GetHomePageData(int id)
        {
            return _context.Bedrijven.Include(s => s.IngediendeStagevoorstellen).FirstOrDefault(s => s.Id == id);
        }

        public Bedrijf Post(Bedrijf bedrijf)
        {
            _context.Bedrijven.Add(bedrijf);
            _context.SaveChanges();
            return bedrijf;
        }

        public void Update(Bedrijf bedrijf)
        {
            // TODO
        }

        public void Delete(int id)
        {
            Bedrijf bedrijf = _context.Bedrijven.FirstOrDefault(s => s.Id == id);
            _context.Bedrijven.Remove(bedrijf);
            _context.SaveChanges();
        }
    }
}
