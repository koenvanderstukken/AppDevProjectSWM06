﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Internship.Data.DomainClasses;
using System.Data.Entity;

namespace Internship.Data.Repositories
{
    public class LectorDBRepository : ILectorRepository
    {
        private InternshipDB _context;

        public LectorDBRepository(InternshipDB context)
        {
            _context = context;
        }

        public IEnumerable<Lector> GetAll()
        {
            return _context.Lectoren.ToList();
        }

        public Lector Get(int id)
        {
            return _context.Lectoren.FirstOrDefault(l => l.Id == id);
        }


        public Lector GetHomePageData(int id)
        {
            return
                _context.Lectoren.Include(l => l.BehandeldeStageVoorstellen)
                    .Include(l => l.TeBehandelenStageVoorstellen)
                    .FirstOrDefault(s => s.Id == id);
        }

        public Lector Post(Lector lector)
        {
            _context.Lectoren.Add(lector);
            _context.SaveChanges();
            return lector;
        }

        public void Update(Lector lector)
        {
            // TODO
        }

        public void Delete(int id)
        {
            Lector lector = _context.Lectoren.FirstOrDefault(l => l.Id == id);
            _context.Lectoren.Remove(lector);
            _context.SaveChanges();
        }
    }
}
