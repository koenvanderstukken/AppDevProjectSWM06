﻿namespace Internship.Data.DomainClasses
{
    public class SchoolPersoon : Persoon
    {
        public int Nummer { get; set; }
        public string SchoolMail { get; set; }
    }
}