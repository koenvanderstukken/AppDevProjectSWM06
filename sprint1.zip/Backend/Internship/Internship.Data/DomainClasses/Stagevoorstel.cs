﻿using Internship.Data.DomainClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Build.Framework;

namespace Internship.Data.DomainClasses
{
    public class Stagevoorstel
    {
        public int Id { get; set; }
        public DateTime TimeStamp { get; set; }
        public String Bemerkingen { get; set; }
        public bool Verstuurd { get; set; }

        public virtual Stageopdracht Stageopdracht { get; set; }
        public virtual Bedrijf Opdrachtgever { get; set; }
        public Review Review { get; set; }
        public Lector ToegewezenLector { get; set; }
        public Lector ReviewLector { get; set; }
        public Stagecoördinator StagecoördinatorBehandelingLector { get; set; }
    }
}
