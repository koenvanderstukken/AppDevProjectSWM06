using System.Collections.Generic;
using Internship.Data.DomainClasses;

namespace Internship.Data.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Internship.Data.InternshipDB>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Internship.Data.InternshipDB context)
        {
            context.Bedrijven.AddOrUpdate(b => b.Bedrijfsnaam,
                new Bedrijf()
                {
                    Telefoonnummer = "011897890",
                    AanwezigheidHandshake = true,
                    Bedrijfsnaam = "Cegeka",
                    Adres = "Berglaan",
                    Huisnummer = 200,
                    Gemeente = "Hasselt",
                    Postcode = 3910,
                    Email = "info@cegeka.com",
                },
                new Bedrijf()
                {
                    Telefoonnummer = "011865457",
                    AanwezigheidHandshake = false,
                    Bedrijfsnaam = "Data Unit",
                    Adres = "Lindekensveld 5",
                    Huisnummer = 20,
                    Gemeente = "Lummen",
                    Postcode = 3560,
                    Email = "info@dataunit.com",
                });
            context.SaveChanges();

            context.Bedrijfspromotors.AddOrUpdate(p => p.Achternaam,
                new Bedrijfspromotor()
                {
                    Voornaam = "Jos",
                    Achternaam = "Lamers",
                    Telefoonnummer = "011787898",
                    Email = "Jos.lamers@cegeka.com",
                    Bedrijf = context.Bedrijven.FirstOrDefault(b => b.Id == 1)
                },
                new Bedrijfspromotor()
                {
                    Voornaam = "Pieter",
                    Achternaam = "Rubens",
                    Telefoonnummer = "011279207",
                    Email = "Pieter.rubens@dataunit.be",
                    Bedrijf = context.Bedrijven.FirstOrDefault(b => b.Id == 2),
                });
            context.SaveChanges();

            context.Contactpersonen.AddOrUpdate(c => c.Achternaam,
                new Contactpersoon()
                {
                    Voornaam = "Elke",
                    Achternaam = "Vandenberk",
                    Telefoonnummer = "011678878",
                    Email = "Elke.vandenberk@cegeka.be"
                },
                new Contactpersoon()
                {
                    Voornaam = "Johan",
                    Achternaam = "Holseyns",
                    Telefoonnummer = "011279207",
                    Email = "Johan.holsteyns@dataunit.be",
                });
            context.SaveChanges();

            context.Stageco�rdinators.AddOrUpdate(s => s.Voornaam,
                new Stageco�rdinator()
                {
                    Voornaam = "Tristan",
                    Achternaam = "Fransen",
                    Telefoonnummer = "0456789888",
                    Email = "Tristan.fransen@gmail.com",
                    Nummer = 02747593,
                    SchoolMail = "Tristan.fransen@pxl.be",
                });
            context.SaveChanges();

            context.Lectoren.AddOrUpdate(s => s.Voornaam,
                new Lector()
                {
                    Achternaam = "Lambrechts",
                    Voornaam = "Rita",
                    MagReviewen = true,
                    SchoolMail = "rita.lambrechts@pxl.be",
                    Telefoonnummer = "047890878",
                    Afstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling
                },
                new Lector()
                {
                    Achternaam = "Heyns",
                    Voornaam = "Bram",
                    MagReviewen = true,
                    SchoolMail = "bram.heyns@pxl.be",
                    Telefoonnummer = "0478678798",
                    Afstudeerrichting = Afstudeerrichting.SysteemEnNetwerkbeheer
                });
            context.SaveChanges();

            context.Studenten.AddOrUpdate(s => s.Achternaam,
                new Student()
                {
                    Afstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling,
                    Voornaam = "Ybe",
                    Achternaam = "Spapen",
                    Telefoonnummer = "0478098780",
                    Email = "Spapenybe@hotmail.com",
                    SchoolMail = "Ybe.Spapen@student.pxl.be",
                    Nummer = 11156786,
                    StageToegekend = false
                },
                new Student()
                {
                    Afstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling,
                    Voornaam = "Anissa",
                    Achternaam = "Schirock",
                    Telefoonnummer = "0478095687",
                    Email = "AnissaSchirock@hotmail.com",
                    SchoolMail = "Anissa.Schirock@student.pxl.be",
                    Nummer = 1109778,
                    StageToegekend = false
                });
            context.SaveChanges();

            context.Stagevoorstellen.AddOrUpdate(s => s.Bemerkingen,
                //NIEUW STAGEVOORSTEL
                new Stagevoorstel()
                {
                    Stageopdracht = new Stageopdracht()
                    {
                        Opdrachtgever = context.Bedrijven.FirstOrDefault(s => s.Id == 2),
                        Status = Status.Nieuw,
                        Contactpersoon = context.Contactpersonen.FirstOrDefault(c => c.Id == 2),
                        Bedrijfspromotor = context.Bedrijfspromotors.FirstOrDefault(b => b.Id == 2),
                        AantalWerknemers = 78,
                        AantalITWerknemers = 70,
                        AantalITBegeleiders = 4,
                        VoorkeurAfstudeerrichting = Afstudeerrichting.SysteemEnNetwerkbeheer,
                        Omschrijving = "Onderhouden Windows server",
                        InfoOverThema =
                            "Data Unit is een bedrijf gespecialiseerd in het leveren, configureren en onderhouden van het netwerk",
                        Omgeving = "Windows",
                        Verwachtingen = "De student zal een Windows server onderhouden",
                        Locatie = "Lummen",
                        AantalGewensteStagiairs = 1,
                        Randvoorwaarden = "Er kunnen verplaatsingen zijn naar Bxl. De hoofdstage locatie is Lummen",
                        Onderzoeksthema = "Windows",
                        InleidendeActiviteiten = InleidendeActiviteit.CV,
                    },
                    Stageco�rdinatorBehandelingLector = context.Stageco�rdinators.FirstOrDefault(s => s.Id == 1),
                    Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 2),
                    TimeStamp = DateTime.Now,
                    Verstuurd = true,
                    Bemerkingen = "Stageopdracht1",
                },
                //STAGECO�RDINATOR HEEFT LECTOR TOEGEWEZEN
                new Stagevoorstel()
                {
                    Stageopdracht = new Stageopdracht()
                    {
                        Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                        Status = Status.ToegewezenLector,
                        Contactpersoon = context.Contactpersonen.FirstOrDefault(c => c.Id == 1),
                        Bedrijfspromotor = context.Bedrijfspromotors.FirstOrDefault(b => b.Id == 1),
                        AantalWerknemers = 100,
                        AantalITWerknemers = 50,
                        AantalITBegeleiders = 5,
                        VoorkeurAfstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling,
                        Omschrijving =
                            "Ontwikkeling van app voor ziekenhuis overpelt, deze app moet patienten info geven...",
                        InfoOverThema = "De student ontwikkelt een app voor het ziekenhuis overpelt...",
                        Omgeving = "Java, C#",
                        Verwachtingen = "De student zal een app maken voor het ziekenhuis van overpelt",
                        Locatie = "Hasselt",
                        AantalGewensteStagiairs = 2,
                        Randvoorwaarden = "Verplaatsing naar Overpelt is mogelijk",
                        Onderzoeksthema = "Java",
                        InleidendeActiviteiten = InleidendeActiviteit.Solicitatiegesprek,
                    },
                    Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                    ToegewezenLector = context.Lectoren.FirstOrDefault(l => l.Id == 1),
                    TimeStamp = DateTime.Now,
                    Verstuurd = true,
                    Bemerkingen = "Stageopdracht2",
                },
                //GOEDGEKEURD DOOR LECTOR
                new Stagevoorstel()
                {
                    Stageopdracht = new Stageopdracht()
                    {
                        Opdrachtgever = context.Bedrijven.FirstOrDefault(s => s.Id == 2),
                        Status = Status.Goedgekeurd,
                        Contactpersoon = context.Contactpersonen.FirstOrDefault(c => c.Id == 2),
                        Bedrijfspromotor = context.Bedrijfspromotors.FirstOrDefault(b => b.Id == 2),
                        AantalWerknemers = 78,
                        AantalITWerknemers = 70,
                        AantalITBegeleiders = 4,
                        VoorkeurAfstudeerrichting = Afstudeerrichting.SysteemEnNetwerkbeheer,
                        Omschrijving = "Onderhouden Linux server",
                        InfoOverThema =
                            "Data Unit is een bedrijf gespecialiseerd in het leveren, configureren en onderhouden van het netwerk",
                        Omgeving = "Linux",
                        Verwachtingen = "De student zal een Linux server onderhouden",
                        Locatie = "Lummen",
                        AantalGewensteStagiairs = 1,
                        Randvoorwaarden = "Er kunnen verplaatsingen zijn naar Bxl. De hoofdstage locatie is Lummen",
                        Onderzoeksthema = "Linux",
                        InleidendeActiviteiten = InleidendeActiviteit.CV,
                    },
                    Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 2),
                    ReviewLector = context.Lectoren.FirstOrDefault(l => l.Id == 2),
                    TimeStamp = DateTime.Now,
                    Verstuurd = true,
                    Bemerkingen = "Stageopdracht3",
                },
                new Stagevoorstel()
                {
                    Stageopdracht = new Stageopdracht()
                    {
                        Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                        Status = Status.Goedgekeurd,
                        Contactpersoon = context.Contactpersonen.FirstOrDefault(c => c.Id == 1),
                        Bedrijfspromotor = context.Bedrijfspromotors.FirstOrDefault(b => b.Id == 1),
                        AantalWerknemers = 100,
                        AantalITWerknemers = 50,
                        AantalITBegeleiders = 5,
                        VoorkeurAfstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling,
                        Omschrijving =
                            "Ontwikkeling van app voor mobile vikings, deze app moet klanten info geven...",
                        InfoOverThema = "De student ontwikkelt een app voor mobile vikings...",
                        Omgeving = "Java, C#",
                        Verwachtingen = "De student zal een app maken voor mobile vikings",
                        Locatie = "Antwerpen",
                        AantalGewensteStagiairs = 1,
                        Randvoorwaarden = "Verplaatsing naar Antwerpen is mogelijk",
                        Onderzoeksthema = "Java",
                        InleidendeActiviteiten = InleidendeActiviteit.Solicitatiegesprek,
                    },
                    Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                    ReviewLector = context.Lectoren.FirstOrDefault(l => l.Id == 1),
                    TimeStamp = DateTime.Now,
                    Verstuurd = true,
                    Bemerkingen = "Stageopdracht4",
                },
                //AFGEKEURD DOOR LECTOR
                new Stagevoorstel()
                {
                    Stageopdracht = new Stageopdracht()
                    {
                        Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                        Status = Status.Afgekeurd,
                        Contactpersoon = context.Contactpersonen.FirstOrDefault(c => c.Id == 1),
                        Bedrijfspromotor = context.Bedrijfspromotors.FirstOrDefault(b => b.Id == 1),
                        AantalWerknemers = 100,
                        AantalITWerknemers = 50,
                        AantalITBegeleiders = 5,
                        VoorkeurAfstudeerrichting = Afstudeerrichting.ApplicatieOntwikkeling,
                        Omschrijving =
                            "Ontwikkeling van app voor supermarkt, deze app moet klanten info geven...",
                        InfoOverThema = "De student ontwikkelt een app voor een supermarkt in hasselt...",
                        Omgeving = "Java, C#",
                        Verwachtingen = "De student zal een app maken voor het een supermarkt in hasselt",
                        Locatie = "Hasselt",
                        AantalGewensteStagiairs = 2,
                        Randvoorwaarden = "Verplaatsing naar hasselt is mogelijk",
                        Onderzoeksthema = "Java",
                        InleidendeActiviteiten = InleidendeActiviteit.Solicitatiegesprek,
                    },
                    Opdrachtgever = context.Bedrijven.FirstOrDefault(b => b.Id == 1),
                    ReviewLector = context.Lectoren.FirstOrDefault(l => l.Id == 1),
                    TimeStamp = DateTime.Now,
                    Verstuurd = true,
                    Bemerkingen = "Stageopdracht5",
                });
            context.SaveChanges();


            context.Reviews.AddOrUpdate(r => r.Feedback,
                new Review()
                {
                    Stagevoorstel = context.Stagevoorstellen.FirstOrDefault(s => s.Id == 3),
                    Feedback = "Stagevoorstel goedgekeurd, er wordt verder contact met u opgenomen",
                    Reviewer = context.Lectoren.FirstOrDefault(l => l.Id == 2)
                },
                new Review()
                {
                    Stagevoorstel = context.Stagevoorstellen.FirstOrDefault(s => s.Id == 4),
                    Feedback =
                        "Stagevoorstel goedgekeurd, er zijn enkele wijziging gemaakt aan de omschrijving, er wordt verder contact met u opgenomen",
                    Reviewer = context.Lectoren.FirstOrDefault(l => l.Id == 1)
                },
                new Review()
                {
                    Stagevoorstel = context.Stagevoorstellen.FirstOrDefault(s => s.Id == 5),
                    Feedback =
                        "Stagevoorstel afgekeurd, er is onvoldoende informatie gegeven",
                    Reviewer = context.Lectoren.FirstOrDefault(l => l.Id == 1)
                });
            context.SaveChanges();

            Student student = context.Studenten.FirstOrDefault(s => s.Id == 1);
            student.Favorieten.Add(context.Stageopdrachten.FirstOrDefault(s => s.Id == 3));
            student.Favorieten.Add(context.Stageopdrachten.FirstOrDefault(s => s.Id == 4));
            context.SaveChanges();

            List<Student> studenten = new List<Student>();
            studenten.Add(context.Studenten.FirstOrDefault(s => s.Id == 1));

            context.Stages.AddOrUpdate(s => s.EindDatum,
                new Stage()
                {
                    StageOpdracht = context.Stageopdrachten.FirstOrDefault(s => s.Id == 3),
                    StartDatum = new DateTime(2017, 03, 24),
                    EindDatum = new DateTime(2017, 06, 24),
                    Students = studenten,
                    StageStatus = StageStatus.Goedgekeurd
                });
            context.SaveChanges();
        }
    }
}
