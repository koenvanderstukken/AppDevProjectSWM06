<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Home</title>

    <meta name="description" content="Homescreen student">
    <meta name="author" content="AON13">


    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">
    <link href="assets/css/datatables.min.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">
                            <h1>
                                <b>Welkom <?php echo $_POST['username']; ?></b>
                            </h1>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img id="afmeldenPng"
                                                                                            alt="afmelden"
                                                                                            src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="studentHomeScreen.php" class="btn btn-block">Home</a>
                </div>
                <div class="col-md-6">
                    <a href="studentOverzichtStageopdrachten.php" class="btn btn-block">Overzicht stageopdrachten</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

    </div>
    <div class="col-md-12">
        <h3>
            Favoriete stageopdrachten
        </h3>
        <table id="table1" class="table table-bordered">
            <thead>
            <tr>
                <th>
                    Functie
                </th>
                <th>
                    Bedrijf
                </th>
                <th>
                    Plaats
                </th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <br>

    </div>
    <div class="col-md-12">
        <h3>
            Mijn geselecteerde stageopdrachten
        </h3>
        <table id="table2" class="table table-bordered">
            <thead>
            <tr>
                <th>
                    Functie
                </th>
                <th>
                    Bedrijf
                </th>
                <th>
                    Plaats
                </th>
                <th>
                    Status
                </th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        <br>

    </div>
</div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script>
    $(document).ready(function () {
        $.ajax({
            url: "http://localhost:57280/api/Student/home/1",
            type: "Get",
            dataType: "json",
            async: false,
            beforeSend: function (xhr){
                xhr.setRequestHeader('Authorization', "Bearer <?php echo $_POST['token'] ?>");
            },
            success: function (data) {
                // Success callback
                for (var i = 0; i < data.Favorieten.length; i++) {
                    var functie = data.Favorieten[i].Omgeving;
                    var bedrijf = data.Favorieten[i].Opdrachtgever.Bedrijfsnaam;
                    var plaats = data.Favorieten[i].Locatie;
                    $('#table1 tbody').append('<tr><td>' + functie + '</td><td>' + bedrijf + '</td><td>' + plaats + '</td></tr>');
                }

                var functie = data.GekozenStageOpdracht.StageOpdracht.Omgeving;
                var bedrijf = data.GekozenStageOpdracht.StageOpdracht.Opdrachtgever.Bedrijfsnaam;
                var plaats = data.GekozenStageOpdracht.StageOpdracht.Locatie;
                var status = data.GekozenStageOpdracht.StageStatus;
                if(status == 0){
                    status = "In behandeling";
                    $('#table2 tbody').append('<tr class="warning"><td>' + functie + '</td><td>' + bedrijf + '</td><td>' + plaats + '</td><td>' + status + '</td></tr>');
                }else if(status == 1){
                    status = "Goedgekeurd";
                    $('#table2 tbody').append('<tr class="success"><td>' + functie + '</td><td>' + bedrijf + '</td><td>' + plaats + '</td><td>' + status + '</td></tr>');
                }else{
                    status = "Afgekeurd"
                    $('#table2 tbody').append('<tr class="danger"><td>' + functie + '</td><td>' + bedrijf + '</td><td>' + plaats + '</td><td>' + status + '</td></tr>');
                }

            },
            error: function (msg) {
                alert("Error!" + msg.toString());
            }
        });

        $('#table1').DataTable();
        $('#table2').DataTable();
    });
</script>
</body>
</html>