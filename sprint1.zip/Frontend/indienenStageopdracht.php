<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Voorstel stageopdracht</title>

    <meta name="description" content="Review Stageopdracht">
    <meta name="author" content="AON13">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img id="afmeldenPng"
                                                                                            alt="afmelden"
                                                                                            src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="lectorHomeScreen.php" class="btn btn-block home-btn">Home</a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <h2>
            Voorstel stageopdracht
        </h2>
        <div>
            <span style="text-align: center">
                <p>Via onderstaand formulier kunnen stageopdrachten voor PXL-IT worden ingegeven. Er staat geen limiet op het aantal opdrachten dat ingestuurd kan worden per bedrijf, maar we beperken het aantal stagiairs per bedrijf tot 2. </p>
                <p>Hopend op uw begrip.</p>
                <p>Stageperiodes: <br>
                - 19 september 2016 tot en met 16 december 2016 (semester 1)<br>
                - 3 oktober 2016 tot en met 13 januari 2017 (semester 1)<br>
                - 20 februari 2017 tot en met 2 juni 2017 (semester 2)<br></p>
            </span>
            <span style="color: red">Vereist *</span>
        </div>
        <form>
            <div id="stageopdracht">
                <h3>Stageopdracht</h3>
                <p>
                    Info onderzoekstopic:
                    <a href="https://docs.google.com/document/d/1MiIpI7U51rwLPKmZY2Cvq7tSqqtEloRp8lvVE06DRj4/edit?usp=sharing ">https://docs.google.com/document/d/1MiIpI7U51rwLPKmZY2Cvq7tSqqtEloRp8lvVE06DRj4/edit?usp=sharing </a>
                </p>
                <br>
                <label>Voorkeur afstudeerrichting *<br><span style="color: darkgray;font-size: smaller">Selecteer hier de afstudeerrichting waarvoor de stageopdracht bestemd is.</span></label><br>
                <input type="checkbox" name="VoorkeurAfstudeerrichting" value=0 checked>Applicatie-ontwikkeling<br>
                <input type="checkbox" name="VoorkeurAfstudeerrichting" value=1>Systemen en Netwerkbeheer<br>
                <input type="checkbox" name="VoorkeurAfstudeerrichting" value=2>Software Management<br>
                <br>
                <label>Omschrijving van de opdracht *<br><span style="color: darkgray;font-size: smaller">Beschrijf hier duidelijk en zo gedetailleerd mogelijk wat de stageopdracht inhoudelijk zal omvatten.</span></label><br>
                <textarea name="Omschrijving" rows="7" cols="60" required>Student maakt een applicatie voor een supermarkt</textarea>
                <br>
                <label>Omgeving<br><span style="color: darkgray;font-size: smaller">In welke IT-omgeving dient de stageopdracht uitgewerkt te worden: bijvoorbeeld</span></label><br>
                <input type="checkbox" name="Omgeving" value="Programmeren: Java" checked>Programmeren: Java<br>
                <input type="checkbox" name="Omgeving" value="Programmeren: .Net">Programmeren: .Net<br>
                <input type="checkbox" name="Omgeving" value="Web: CSS, Javascript, PHP, Angular, ...">Web: CSS, Javascript, PHP, Angular, ...<br>
                <input type="checkbox" name="Omgeving" value="Mobile: Android, iOS, Windows, ...">Mobile: Android, iOS, Windows, ...<br>
                <input type="checkbox" name="Omgeving" value="Systemen&Netwerken:  Linux, Windows, ...">Systemen&Netwerken:  Linux, Windows, ...<br>
                <input type="checkbox" name="Omgeving" value="Software testing, ITIL, Projectmanagement, CRM, Information Management">Software testing, ITIL, Projectmanagement, CRM, Information Management<br>
                <br>
                <label>Randvoorwaarden<br><span style="color: darkgray;font-size: smaller">Zijn er specifieke eisen waaraan moet worden voldaan voor het uitvoeren van de stageopdracht vb bereidheid tot communicatie in het Engels, beschikken over een auto, bereikbaar met openbaar vervoer,...</span></label>
                <br>
                <textarea name="Randvoorwaarden" rows="7" cols="60">Student moet zich kunnen verplaatsen naar Brussel</textarea>
                <br>
                <label>Onderzoeksthema<br><span style="color: darkgray;font-size: smaller">Onderzoek dat leidt tot het vergaren van diepgaande kennis voor het oplossen van een praktijkprobleem. Het thema kan zich situeren in het kader of in het verlengde van de stageopdracht ofwel een specifieke onderzoeksopdracht aangebracht door het bedrijf (zie begeleidende brief voor enkele voorbeelden)</span></label>
                <textarea name="Onderzoeksthema" rows="7" cols="60">Onderzoeksthema,...</textarea>
                <br>
                <h3>Overige</h3>
                <label>Inleidende activiteiten / verwachtingen</label><br>
                <input type="checkbox" name="InleidendeActiviteit" value=0 checked>CV<br>
                <input type="checkbox" name="InleidendeActiviteit" value=1>Sollicitatiegesprek<br>
                <input type="checkbox" name="InleidendeActiviteit" value=2>Vergoeding / tegemoetkoming in verplaatsingskosten<br>
                <br>
                <label>Aantal gewenste stagiairs (max. 2 per stageproject) *</label><br>
                <input type="radio" name="AantalGewensteStagiairs" value=0 checked>1 student<br>
                <input type="radio" name="AantalGewensteStagiairs" value=1>2 studenten<br>
                <br>
                <br>
                <label>Stageperiode *</label><br>
                <input type="checkbox" name="Stageperiode" value=0 checked>Semester 1 (19/09/2016-16/12/2016 OF 03/10/2016-13/01/2017)<br>
                <input type="checkbox" name="Stageperiode" value=1>Semester 2 (20/02/2017-02/06/2017)<br>
                <h3>Locatie</h3>
                <br>
                <label>Locatie van de stage (indien elders dan het adres van het stagebedrijf)<br>
                    <span style="color: darkgray;font-size: smaller">Straat - Nr - Pc - Gemeente</span></label><br>
                <textarea name="Locatie" rows="7" cols="60">Torenlaan 500 Brussel</textarea>
                <br>
                <label>Aantal Medewerkers (op het bedrijf) *</label><br>
                <input name="AantalWerknemers" type="number" value="200" required>
                <br>
                <label>Aantal IT-medewerkers (op het bedrijf) *</label><br>
                <input name="AantalITWerknemers" type="number" value="100" required>
                <br>
                <label>Aantal IT-medewerkers (op het bedrijf) *<br>
                    <span style="color: darkgray;font-size: smaller">die de student technisch kunnen begeleiden bij het uitwerken van zijn stageopdracht</span></label><br>
                <input name="AantalITBegeleiders" type="number" value="10" required>
                <br>
            </div>
            <div id="contactpersoon">
                <h3>
                    Contactpersoon
                </h3>
                <p>Deze persoon zal de stagedocumenten ondertekenen</p>
                <br>
                <label>Titel *</label><br>
                <input type="text" name="Title" value="Mvr" required>
                <br>
                <label>Naam *</label><br>
                <input type="text" name="Achernaam" value="Janssen" required>
                <br>
                <label>Voornaam *</label><br>
                <input type="text" name="Voornaam" value="Eva" required>
                <br>
                <label>Telefoonnummer *<br>
                    <span style="color: darkgray;font-size: smaller">Formaat: +32 11 123456 of +32 496 123456</span></label><br>
                <input type="text" name="Telefoonnummer" required pattern=".*\+?\(?\d{2,4}\)?[\d\s-]{3,}.*" value="011787878">
                <br>
                <label>E-mail adres contactpersoon *</label><br>
                <input type="text" name="Email" required pattern=".*[a-zA-Z0-9_\.\+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-\.]+.*" value="eva.janssen@hotmail.com">
                <br>
            </div>
            <div id ="bedrijfspromotor">
                <h3>Bedrijfspromotor (in het bedrijf)</h3>
                <p>
                    Deze persoon zal de student technisch begeleiden tijdens de stageperiode en zal tevens aanwezig zijn tijdens het juryexamen van de student
                </p>
                <br>
                <label>Titel *</label><br>
                <input type="text" name="Title" value="Mr" required>
                <br>
                <label>Naam *</label><br>
                <input type="text" name="Achternaam" value="Janssen" required>
                <br>
                <label>Voornaam *</label><br>
                <input type="text" name="Voornaam" value="Jos" required>
                <br>
                <label>Telefoonnummer *<br>
                    <span  style="color: darkgray;font-size: smaller">Formaat: +32 11 123456 of +32 496 123456</span></label><br>
                <input type="text" name="Telefoonnummer" required pattern=".*\+?\(?\d{2,4}\)?[\d\s-]{3,}.*" value="011565656">
                <br>
                <label>E-mail adres contactpersoon *</label><br>
                <input type="text" name="Email" required pattern=".*[a-zA-Z0-9_\.\+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-\.]+.*" value="jos.janssen@hotmail.com">
                <br>
            </div>
            <br>
            <br>
            <button value="Verzenden" class="verzenden" id="sendButton">Verzenden</button>
        </form>
        <br>
    </div>
</div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/jsHome/scripts.js"></script>
<script>
    $("#sendButton").click(function () {
        var contactpersoon = $("#contactpersoon :input").serializeArray();
        var bedrijfspromotor = $("#bedrijfspromotor :input").serializeArray();
        var stageopdracht = $("#stageopdracht :input").serializeArray();
        var stagevoorstel = [];
        stageopdracht[stageopdracht.length] = { name: "Bedrijfspromotor", value: bedrijfspromotor };
        stageopdracht[stageopdracht.length] = { name: "Contactpersoon", value: contactpersoon };
        stageopdracht[stageopdracht.length] = { name: "Opdrachtgever", value: 1 };
        stagevoorstel[stagevoorstel.length] = { name: "Timestamp", value: new Date($.now()) };
        stagevoorstel[stagevoorstel.length] = { name: "Verstuurd", value: true };
        stagevoorstel[stagevoorstel.length] = { name: "Stageopdracht", value: stageopdracht };
        var data = JSON.stringify(stagevoorstel);
        //var data = stagevoorstel;
        postData(data);

        alert(data);
    });

    function postData(data){
        $(document).ready(function () {
            $.ajax({
                url: 'http://localhost:57280/api/stagevoorstellen',
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                dataType: 'application/json',
                data: data,
                success: function (data) {
                    alert("sucess!")
                },
                error : function(jqXHR, textStatus, errorThrown) { alert("Error: Status: "+textStatus+" Message: "+errorThrown); }
            });
        });
    }
</script>
</body>
</html>