<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Home</title>

    <meta name="description" content="Overzicht stageopdrachten">
    <meta name="author" content="AON13">


    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/styleHome.css" rel="stylesheet">
    <link href="assets/css/datatables.min.css" rel="stylesheet">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-5">
                        </div>
                        <div class="col-md-7">

                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-9">
                        </div>
                        <div class="col-md-3">
                            <a href="verwerkAfmelden.php" class="btn btn-link">Afmelden<img id="afmeldenPng" alt="afmelden"
                                                                                            src="assets/img/afmelden.png"/></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <img id="logoPxl" alt="Logo pxl" src="assets/img/pxllogowitterand.png">
                    <a href="studentHomeScreen.php" class="btn btn-block">Home</a>
                </div>
                <div class="col-md-6">
                    <a href="studentOverzichtStageopdrachten.php" class="btn btn-block">Overzicht stageopdrachten</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

    </div>
</div>
<div class="col-md-12">
    <h3>
        Overzicht stageopdrachten
    </h3>
    <table id="table2" class="table table-bordered">
        <thead>
        <tr>
            <th>
                Functie
            </th>
            <th>
                Bedrijf
            </th>
            <th>
                Plaats
            </th>
            <th>
                Markeer als favoriet
            </th>
        </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
    <br>

</div>
</div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/scriptHome.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script>
    $(document).ready(function() {
        $.ajax({
            url: "http://localhost:57280/api/stageopdrachten/goedgekeurd",
            type: "Get",
            dataType: "json",
            async: false,
            success: function (data) {
                // Success callback
                var len = data.length;

                for (var i = 0; i < len; i++) {
                    var functie = data[i].Omgeving;
                    var bedrijf = data[i].Opdrachtgever.Bedrijfsnaam;
                    var plaats = data[i].Locatie;
                    $('#table2 tbody').append('<tr><td>' + functie + '</td><td>' + bedrijf + '</td><td>' + plaats + '</td><td><button class="hartjeButton"><img class="hartje" src="assets/img/hartjewit.png" alt="hartje"></button></td></tr>')
                }
            },
            error: function (msg) {
                alert("Error!" + msg.toString())
            }
        });
        $('#table1').DataTable();
        $('#table2').DataTable();
    });
</script>
</body>
</html>